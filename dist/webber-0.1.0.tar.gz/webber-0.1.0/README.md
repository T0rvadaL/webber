## Acknowledgments
Webber uses source code [`httpx`](https://www.python-httpx.org/), which is licensed under the BSD 3-Clause License.